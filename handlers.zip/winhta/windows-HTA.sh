# !bin/bash
# Author : Bishal Shaw

msfconsole -r hta-windowshack.rc 