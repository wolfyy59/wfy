# !bin/bash
# Author : Bishal Shaw

msfconsole -r python.rc
